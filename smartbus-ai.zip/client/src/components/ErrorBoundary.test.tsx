import { describe, expect, it, vi } from "vitest";
import ErrorBoundary from "./ErrorBoundary";

describe("ErrorBoundary", () => {
  it("renders children while the tree is healthy", () => {
    const boundary = new ErrorBoundary({ children: "healthy" });

    expect(boundary.render()).toBe("healthy");
  });

  it("derives a fallback state from a render error", () => {
    const error = new Error("component failed");
    const nextState = ErrorBoundary.getDerivedStateFromError(error);

    expect(nextState).toEqual({ hasError: true, error });
  });

  it("logs the error and component stack for diagnostics", () => {
    const boundary = new ErrorBoundary({ children: "healthy" });
    const error = new Error("component failed");
    const consoleSpy = vi.spyOn(console, "error").mockImplementation(() => undefined);

    boundary.componentDidCatch(error, { componentStack: "\n    at BrokenWidget" });

    expect(consoleSpy).toHaveBeenCalledWith(
      "[ErrorBoundary] Unhandled render error",
      error,
      { componentStack: "\n    at BrokenWidget" },
    );
    consoleSpy.mockRestore();
  });
});
