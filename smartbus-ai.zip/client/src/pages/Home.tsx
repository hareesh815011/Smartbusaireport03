import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import {
  Accessibility,
  AlertTriangle,
  ArrowRight,
  Bell,
  Bus,
  Check,
  ChevronDown,
  CircleHelp,
  Clock3,
  Compass,
  Crosshair,
  Flame,
  Footprints,
  Gauge,
  Headphones,
  Home as HomeIcon,
  Loader2,
  Languages,
  LocateFixed,
  MapPinned,
  Menu,
  Mic,
  Moon,
  MoreHorizontal,
  Navigation,
  PanelLeft,
  Phone,
  Pin,
  Play,
  Route,
  Search,
  Settings2,
  ShieldAlert,
  Sparkles,
  Sun,
  TrainFront,
  UserRound,
  Users,
  Volume2,
  WalletCards,
  X,
  Zap,
} from "lucide-react";

type View = "home" | "search" | "map" | "facilities" | "notifications" | "profile";

type NavItem = {
  id: View;
  label: string;
  icon: typeof HomeIcon;
};

type BusSchedule = {
  id: number;
  busNumber: string;
  routeNumber: string;
  origin: string;
  destination: string;
  platform: number;
  departureMinute: number;
  arrivalMinute: number;
  status: "boarding" | "on_time" | "delayed" | "departed";
  delayMinutes: number;
  walkingMinutes: number;
  minutesUntilDeparture: number;
  nextDay: boolean;
};

function formatScheduleTime(minute: number) {
  const hour = Math.floor(minute / 60) % 24;
  const minutePart = String(minute % 60).padStart(2, "0");
  const period = hour >= 12 ? "PM" : "AM";
  const hour12 = hour % 12 || 12;
  return `${hour12}:${minutePart} ${period}`;
}

function formatDuration(startMinute: number, endMinute: number) {
  const totalMinutes = (endMinute - startMinute + 1440) % 1440;
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  return hours > 0 ? `${hours}h ${minutes}m` : `${minutes}m`;
}

function scheduleStatusLabel(status: BusSchedule["status"]) {
  return status === "boarding" ? "Boarding" : status === "delayed" ? "Delayed" : status === "departed" ? "Departed" : "On time";
}

const navItems: NavItem[] = [
  { id: "home", label: "Overview", icon: HomeIcon },
  { id: "search", label: "Find a bus", icon: Search },
  { id: "map", label: "Live map", icon: MapPinned },
  { id: "facilities", label: "Facilities", icon: Compass },
  { id: "notifications", label: "Alerts", icon: Bell },
];

const facilities = [
  { name: "Restroom", meta: "30 m away", icon: "◒", tone: "mint" },
  { name: "Food court", meta: "50 m away", icon: "⌁", tone: "orange" },
  { name: "Help desk", meta: "Counter 5", icon: "?", tone: "blue" },
  { name: "Drinking water", meta: "North wing", icon: "◌", tone: "violet" },
];

const alerts = [
  { title: "Platform change", detail: "TN38 N 2456 now boards at Platform 12", time: "2 min ago", tone: "blue", icon: Navigation },
  { title: "Weather alert", detail: "Light showers expected after 6:00 PM", time: "18 min ago", tone: "yellow", icon: Zap },
  { title: "Gate announcement", detail: "Salem route is ready for boarding", time: "34 min ago", tone: "green", icon: Check },
];

function BusMark({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`brand-mark ${compact ? "brand-mark-compact" : ""}`} aria-hidden="true">
      <div className="brand-mark-road" />
      <Bus size={compact ? 18 : 21} strokeWidth={2.5} />
      <span className="brand-mark-signal signal-one" />
      <span className="brand-mark-signal signal-two" />
    </div>
  );
}

function MiniMap({ expanded = false }: { expanded?: boolean }) {
  return (
    <div className={`mini-map ${expanded ? "mini-map-expanded" : ""}`}>
      <div className="map-grid" />
      <div className="map-road map-road-one" />
      <div className="map-road map-road-two" />
      <div className="map-road map-road-three" />
      <div className="map-water" />
      <div className="map-label label-central">CENTRAL BUS STAND</div>
      <div className="map-label label-omr">SATHY ROAD</div>
      <div className="map-label label-gandhi">GANDHIPURAM</div>
      <div className="map-stop stop-one"><span>12</span></div>
      <div className="map-stop stop-two"><span>08</span></div>
      <div className="map-stop stop-three"><span>04</span></div>
      <div className="map-route route-a" />
      <div className="map-route route-b" />
      <div className="map-pulse"><Bus size={14} /></div>
      <div className="map-you"><LocateFixed size={13} /></div>
      {expanded && <div className="map-compass"><Navigation size={14} /></div>}
      <div className="map-legend">
        <span><i className="dot dot-bus" />Bus live</span>
        <span><i className="dot dot-you" />You</span>
      </div>
    </div>
  );
}

function StatusPill({ children, tone = "green" }: { children: React.ReactNode; tone?: "green" | "blue" | "yellow" | "gray" }) {
  return <span className={`status-pill status-${tone}`}><span className="status-dot" />{children}</span>;
}

function SectionHeading({ eyebrow, title, detail, action }: { eyebrow?: string; title: string; detail?: string; action?: React.ReactNode }) {
  return (
    <div className="section-heading">
      <div>
        {eyebrow && <p className="eyebrow">{eyebrow}</p>}
        <h2>{title}</h2>
        {detail && <p className="section-detail">{detail}</p>}
      </div>
      {action}
    </div>
  );
}

function AppSidebar({ active, setActive, collapsed, onToggle }: { active: View; setActive: (view: View) => void; collapsed: boolean; onToggle: () => void }) {
  return (
    <aside className={`app-sidebar ${collapsed ? "sidebar-collapsed" : ""}`}>
      <div className="sidebar-top">
        <button className="brand-lockup" onClick={() => setActive("home")} aria-label="Go to SmartBus overview">
          <BusMark compact={collapsed} />
          {!collapsed && <span className="brand-copy"><strong>SmartBus</strong><small>AI travel assistant</small></span>}
        </button>
        <button className="icon-button sidebar-toggle" onClick={onToggle} aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}>
          {collapsed ? <PanelLeft size={18} /> : <Menu size={18} />}
        </button>
      </div>

      {!collapsed && <div className="sidebar-context"><span className="context-dot" /><span>Coimbatore Central</span><ChevronDown size={13} /></div>}

      <div className="sidebar-nav">
        <p className="sidebar-label">Workspace</p>
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <button key={item.id} className={`sidebar-link ${active === item.id ? "sidebar-link-active" : ""}`} onClick={() => setActive(item.id)}>
              <Icon size={19} strokeWidth={active === item.id ? 2.5 : 1.8} />
              {!collapsed && <span>{item.label}</span>}
              {item.id === "notifications" && !collapsed && <span className="nav-count">3</span>}
              {collapsed && <span className="tooltip-label">{item.label}</span>}
            </button>
          );
        })}
      </div>

      <div className="sidebar-bottom">
        {!collapsed && <div className="help-card">
          <div className="help-icon"><Headphones size={18} /></div>
          <div><strong>Need a hand?</strong><span>Our team is here 24/7.</span></div>
          <button onClick={() => toast.success("Connecting you to the help desk")}>Contact</button>
        </div>}
        <button className={`sidebar-link ${active === "profile" ? "sidebar-link-active" : ""}`} onClick={() => setActive("profile")}>
          <Settings2 size={19} strokeWidth={1.8} />
          {!collapsed && <span>Settings</span>}
          {collapsed && <span className="tooltip-label">Settings</span>}
        </button>
        {!collapsed && <div className="sidebar-profile" onClick={() => setActive("profile")}>
          <div className="avatar">AR</div><div className="profile-copy"><strong>Arun Raj</strong><span>Passenger account</span></div><MoreHorizontal size={18} />
        </div>}
      </div>
    </aside>
  );
}

function TopBar({ darkMode, onToggleDark, onNotifications, onMenu }: { darkMode: boolean; onToggleDark: () => void; onNotifications: () => void; onMenu: () => void }) {
  return (
    <header className="topbar">
      <button className="mobile-menu icon-button" onClick={onMenu} aria-label="Open navigation"><Menu size={20} /></button>
      <div className="topbar-location"><MapPinned size={17} /><span>Coimbatore Central Bus Stand</span><span className="location-live">LIVE</span></div>
      <div className="topbar-actions">
        <div className="sync-status"><span className="sync-dot" />Synced just now</div>
        <button className="icon-button theme-toggle" onClick={onToggleDark} aria-label="Toggle dark mode">{darkMode ? <Sun size={18} /> : <Moon size={18} />}</button>
        <button className="icon-button notification-button" onClick={onNotifications} aria-label="Open notifications"><Bell size={18} /><span /></button>
        <div className="topbar-avatar">AR</div>
      </div>
    </header>
  );
}

function SearchPanel({ query, setQuery, onSearch, compact = false }: { query: string; setQuery: (value: string) => void; onSearch: () => void; compact?: boolean }) {
  return (
    <div className={`search-panel ${compact ? "search-panel-compact" : ""}`}>
      <div className="search-title-row"><div className="search-spark"><Sparkles size={15} /></div><span>AI-powered journey search</span><span className="search-badge">BETA</span></div>
      <div className="search-input-wrap">
        <Search size={20} />
        <input value={query} onChange={(event) => setQuery(event.target.value)} onKeyDown={(event) => event.key === "Enter" && onSearch()} placeholder="Where do you want to go?" aria-label="Destination" />
        {query && <button className="clear-input" onClick={() => setQuery("")} aria-label="Clear destination"><X size={16} /></button>}
        <button className={`voice-button ${query ? "voice-button-filled" : ""}`} onClick={() => toast.info("Voice search is listening… try saying ‘Salem’")} aria-label="Start voice search"><Mic size={18} /></button>
        <button className="search-submit" onClick={onSearch}><ArrowRight size={18} /></button>
      </div>
      {!compact && <div className="recent-row"><span>Try saying</span><button onClick={() => setQuery("Salem")}>Salem</button><button onClick={() => setQuery("Bengaluru")}>Bengaluru</button><button onClick={() => setQuery("Mettupalayam")}>Mettupalayam</button><span className="language-note"><Languages size={13} /> English · தமிழ்</span></div>}
    </div>
  );
}

function MetricCard({ icon, label, value, helper, tone }: { icon: React.ReactNode; label: string; value: string; helper: string; tone: string }) {
  return <div className={`metric-card metric-${tone}`}><div className="metric-icon">{icon}</div><div className="metric-content"><span>{label}</span><strong>{value}</strong><small>{helper}</small></div><span className="metric-sparkline"><i /><i /><i /><i /><i /></span></div>;
}

function TripCard({ schedule, onRoute }: { schedule?: BusSchedule | null; onRoute: () => void }) {
  const departureTime = schedule ? formatScheduleTime(schedule.departureMinute) : "—";
  const arrivalTime = schedule ? formatScheduleTime(schedule.arrivalMinute) : "—";
  const routeDuration = schedule ? formatDuration(schedule.departureMinute, schedule.arrivalMinute) : "Loading";
  const statusTone = schedule?.status === "delayed" ? "yellow" : schedule?.status === "departed" ? "gray" : "green";
  return (
    <article className="card trip-card">
      <div className="card-topline"><div><p className="eyebrow">NEXT DATABASE DEPARTURE</p><h3>{schedule?.destination ?? "Bus timings"} <span>→</span> {schedule?.origin ?? "Coimbatore"}</h3></div><button className="round-more" aria-label="More trip options"><MoreHorizontal size={17} /></button></div>
      <div className="trip-route"><div className="route-node"><span className="route-time">{departureTime}</span><span className="route-place">Platform {schedule?.platform ?? "—"}</span></div><div className="route-line"><span className="route-line-progress" /><Bus size={15} /></div><div className="route-node route-node-end"><span className="route-time">{arrivalTime}</span><span className="route-place">{schedule?.destination ?? "—"}</span></div></div>
      <div className="trip-meta"><StatusPill tone={statusTone}>{schedule ? scheduleStatusLabel(schedule.status) : "Loading"}</StatusPill><span><Clock3 size={14} /> {routeDuration}</span><span><Footprints size={14} /> {schedule?.walkingMinutes ?? "—"} min walk</span></div>
      <button className="outline-action" onClick={onRoute}>Open live route <ArrowRight size={16} /></button>
    </article>
  );
}

function LiveMapCard({ onOpen }: { onOpen: () => void }) {
  return (
    <article className="card live-card">
      <div className="card-topline"><div><p className="eyebrow">LIVE OPERATIONS</p><h3>Stand activity</h3></div><StatusPill tone="blue">Updating live</StatusPill></div>
      <div className="live-map-wrap"><MiniMap /></div>
      <div className="live-footer"><div className="live-stat"><strong>28</strong><span>buses on site</span></div><div className="live-stat"><strong>84%</strong><span>on time today</span></div><button className="icon-action" onClick={onOpen} aria-label="Open live map"><ArrowRight size={17} /></button></div>
    </article>
  );
}

function QuickActions({ setActive }: { setActive: (view: View) => void }) {
  const actions = [
    { label: "Find a bus", helper: "Search routes", icon: Search, view: "search" as View, tone: "blue" },
    { label: "Platform guide", helper: "Walk with ease", icon: Route, view: "map" as View, tone: "green" },
    { label: "Nearby facilities", helper: "Restrooms & more", icon: Compass, view: "facilities" as View, tone: "orange" },
    { label: "Emergency help", helper: "Get assistance", icon: ShieldAlert, view: "notifications" as View, tone: "red" },
  ];
  return <div className="quick-grid">{actions.map((action) => { const Icon = action.icon; return <button className="quick-action" key={action.label} onClick={() => action.view === "notifications" ? toast.error("Emergency services are on standby", { description: "Call control room · 0422 230 1234" }) : setActive(action.view)}><span className={`quick-icon quick-${action.tone}`}><Icon size={19} /></span><span><strong>{action.label}</strong><small>{action.helper}</small></span><ArrowRight size={16} /></button>; })}</div>;
}

function HomeView({ setActive, query, setQuery, onSearch, summary, isSummaryLoading }: { setActive: (view: View) => void; query: string; setQuery: (value: string) => void; onSearch: () => void; summary?: { total: number; onTime: number; nextDeparture: BusSchedule | null }; isSummaryLoading: boolean }) {
  const nextDeparture = summary?.nextDeparture;
  const onTimeRate = summary?.total ? `${Math.round((summary.onTime / summary.total) * 100)}%` : "—";
  return <>
    <section className="welcome-row"><div><p className="eyebrow greeting-eyebrow">SATURDAY, 13 SEPTEMBER 2026 <span className="sunny-dot" /></p><h1>Good evening, Arun<span className="wave">✦</span></h1><p className="welcome-copy">Make your next connection feel effortless.</p></div><div className="weather-card"><div className="weather-icon"><Sun size={20} /></div><div><strong>29°</strong><span>Partly cloudy</span></div><span className="weather-place">Coimbatore</span></div></section>
    <section className="hero-search"><div className="hero-search-copy"><div className="hero-icon"><Sparkles size={17} /></div><div><p className="eyebrow">YOUR AI TRAVEL ASSISTANT</p><h2>Where are you heading today?</h2><p>Tell me your destination and I’ll find the fastest way there.</p></div></div><SearchPanel query={query} setQuery={setQuery} onSearch={onSearch} /></section>
    <div className="metrics-grid"><MetricCard icon={<Bus size={19} />} label="Schedules live" value={isSummaryLoading ? "…" : String(summary?.total ?? 0)} helper="From SmartBus database" tone="blue" /><MetricCard icon={<Gauge size={19} />} label="On-time rate" value={isSummaryLoading ? "…" : onTimeRate} helper="Based on active schedules" tone="green" /><MetricCard icon={<Users size={19} />} label="Stand crowd" value="Moderate" helper="Best time to travel" tone="violet" /><MetricCard icon={<Clock3 size={19} />} label="Next departure" value={nextDeparture ? formatScheduleTime(nextDeparture.departureMinute) : "…"} helper={nextDeparture ? `Platform ${nextDeparture.platform} · ${nextDeparture.destination}` : "Loading timings"} tone="orange" /></div>
    <div className="dashboard-grid"><TripCard schedule={nextDeparture} onRoute={() => setActive("map")} /><LiveMapCard onOpen={() => setActive("map")} /></div>
    <section className="lower-section"><SectionHeading eyebrow="MAKE IT EASY" title="Quick access" detail="Everything you need at the stand." action={<button className="text-action" onClick={() => toast.info("All passenger tools are shown here")}>View all <ArrowRight size={15} /></button>} /><QuickActions setActive={setActive} /></section>
    <section className="lower-section facilities-section"><SectionHeading eyebrow="AROUND YOU" title="Nearby facilities" detail="Helpful spots within a short walk." action={<button className="text-action" onClick={() => setActive("facilities")}>Explore map <ArrowRight size={15} /></button>} /><div className="facility-row">{facilities.map((facility) => <button className="facility-card" key={facility.name} onClick={() => toast.success(`${facility.name} selected`, { description: facility.meta })}><span className={`facility-icon facility-${facility.tone}`}>{facility.icon}</span><span className="facility-copy"><strong>{facility.name}</strong><small>{facility.meta}</small></span><ArrowRight size={15} /></button>)}</div></section>
  </>;
}

function SearchView({ query, setQuery, onSearch, setActive, schedules, isLoading }: { query: string; setQuery: (value: string) => void; onSearch: () => void; setActive: (view: View) => void; schedules: BusSchedule[]; isLoading: boolean }) {
  const topMatch = schedules[0];
  return <section className="detail-view"><SectionHeading eyebrow="SMART SEARCH" title="Find your bus" detail="Search a destination to see AI-ranked buses, platforms, and walking time." action={<button className="back-action" onClick={() => setActive("home")}><ArrowRight size={15} className="back-arrow" />Back to overview</button>} /><SearchPanel query={query} setQuery={setQuery} onSearch={onSearch} compact /><div className="search-result-layout"><div className="card result-card">{isLoading ? <div className="empty-schedule"><Loader2 size={20} className="spin" /><strong>Reading live schedules…</strong><span>Checking the SmartBus database.</span></div> : topMatch ? <><div className="result-header"><div><p className="eyebrow">TOP MATCH · AI RECOMMENDED</p><h3>{topMatch.busNumber}</h3><p>{topMatch.destination} Express · Route {topMatch.routeNumber}</p></div><StatusPill tone={topMatch.status === "delayed" ? "yellow" : topMatch.status === "departed" ? "gray" : "green"}>{scheduleStatusLabel(topMatch.status)}</StatusPill></div><div className="result-grid"><div><span>Platform</span><strong>{topMatch.platform}</strong></div><div><span>Departure</span><strong>{formatScheduleTime(topMatch.departureMinute)}</strong></div><div><span>Expected arrival</span><strong>{formatScheduleTime(topMatch.arrivalMinute)}</strong></div><div><span>Walk from here</span><strong>{topMatch.walkingMinutes} min</strong></div></div><div className="result-route"><div className="route-progress-label"><span><i /> {topMatch.status === "delayed" ? `${topMatch.delayMinutes} min delay` : "Schedule confirmed"}</span><span>{topMatch.nextDay ? "Tomorrow" : `Leaves in ${topMatch.minutesUntilDeparture} min`}</span></div><div className="progress-track"><div style={{ width: `${Math.min(92, Math.max(18, 100 - topMatch.minutesUntilDeparture / 2))}%` }} /></div></div><div className="result-actions"><button className="primary-button" onClick={() => setActive("map")}>Navigate to Platform {topMatch.platform} <Navigation size={17} /></button><button className="secondary-button" onClick={() => toast.success(`${topMatch.busNumber} saved to your trips`)}>Save trip <Pin size={16} /></button></div></> : <div className="empty-schedule"><CircleHelp size={20} /><strong>No matching departures</strong><span>Try Salem, Bengaluru, or Mettupalayam.</span></div>}</div><div className="ai-note"><div className="ai-note-icon"><Sparkles size={18} /></div><div><p className="eyebrow">SMARTBUS AI SUGGESTS</p><strong>{topMatch ? `Leave in the next ${Math.max(1, topMatch.minutesUntilDeparture - topMatch.walkingMinutes)} minutes` : "Search a destination to get started"}</strong><p>{topMatch ? `Platform ${topMatch.platform} is a ${topMatch.walkingMinutes}-minute walk from your current location. The route is stored in the live schedule database.` : "We’ll rank the nearest available departures and show the best walking route."}</p></div></div></div>{schedules.length > 1 && <div className="card departures-card"><div className="card-topline"><div><p className="eyebrow">UPCOMING FROM DATABASE</p><h3>More departures</h3></div><StatusPill tone="blue">{schedules.length} matches</StatusPill></div><div className="departures-list">{schedules.slice(1).map((schedule) => <button className="departure-row" key={schedule.id} onClick={() => toast.info(`${schedule.busNumber} · Platform ${schedule.platform}`, { description: `${formatScheduleTime(schedule.departureMinute)} to ${schedule.destination}` })}><span className="departure-time">{formatScheduleTime(schedule.departureMinute)}</span><span className="departure-route"><strong>{schedule.busNumber}</strong><small>{schedule.destination} · Platform {schedule.platform}</small></span><StatusPill tone={schedule.status === "delayed" ? "yellow" : "green"}>{scheduleStatusLabel(schedule.status)}</StatusPill><ArrowRight size={15} /></button>)}</div></div>}</section>;
}

function MapView({ setActive }: { setActive: (view: View) => void }) {
  return <section className="detail-view"><SectionHeading eyebrow="LIVE WAYFINDING" title="Platform guide" detail="Follow the clearest route from your location to Platform 12." action={<button className="back-action" onClick={() => setActive("home")}><ArrowRight size={15} className="back-arrow" />Back to overview</button>} /><div className="map-layout"><div className="card full-map-card"><div className="map-toolbar"><div><p className="eyebrow">COIMBATORE CENTRAL</p><h3>Stand map <span className="map-updated"><span />Updated 10 sec ago</span></h3></div><div className="map-tools"><button className="map-tool active"><Navigation size={15} />Route</button><button className="map-tool"><Accessibility size={15} />Accessible</button></div></div><MiniMap expanded /></div><aside className="card route-card"><div className="route-card-icon"><Footprints size={20} /></div><p className="eyebrow">YOUR WALKING ROUTE</p><h3>Platform 12</h3><p className="route-card-copy">Follow the blue line past the help desk and north concourse.</p><div className="route-time-block"><strong>2 <small>min</small></strong><span>Approx. 180 m</span></div><div className="route-steps"><div className="route-step"><span className="step-dot step-current" /><div><strong>You are here</strong><small>Main entrance · Gate A</small></div></div><div className="step-line" /><div className="route-step"><span className="step-dot step-stop" /><div><strong>Pass Help Desk</strong><small>Counter 5 · 60 m</small></div></div><div className="step-line" /><div className="route-step"><span className="step-dot step-destination" /><div><strong>Platform 12</strong><small>Salem Express · Boarding</small></div></div></div><button className="primary-button route-start" onClick={() => toast.success("Navigation started", { description: "We’ll keep the route open while you walk." })}><Play size={16} fill="currentColor" />Start walking</button></aside></div></section>;
}

function FacilitiesView({ setActive }: { setActive: (view: View) => void }) {
  const allFacilities = [...facilities, { name: "ATM", meta: "East wing · 80 m", icon: "₹", tone: "green" }, { name: "Medical centre", meta: "Open 24/7", icon: "+", tone: "red" }, { name: "Charging station", meta: "6 slots free", icon: "⌁", tone: "violet" }, { name: "Lost & found", meta: "Admin block", icon: "◈", tone: "orange" }];
  return <section className="detail-view"><SectionHeading eyebrow="STAND ESSENTIALS" title="Nearby facilities" detail="A calmer journey starts with knowing what’s around you." action={<button className="back-action" onClick={() => setActive("home")}><ArrowRight size={15} className="back-arrow" />Back to overview</button>} /><div className="facility-detail-grid">{allFacilities.map((facility) => <button className="facility-detail-card" key={facility.name} onClick={() => toast.success(facility.name, { description: `${facility.meta} · Walking route ready` })}><div className={`facility-icon facility-${facility.tone}`}>{facility.icon}</div><div><strong>{facility.name}</strong><span>{facility.meta}</span><small><Footprints size={12} /> Walking route ready</small></div><ArrowRight size={17} /></button>)}</div><div className="accessibility-banner"><div className="accessibility-icon"><Accessibility size={20} /></div><div><p className="eyebrow">DESIGNED FOR EVERY PASSENGER</p><strong>Need an accessible route?</strong><span>We’ll avoid stairs and guide you via ramps and lifts.</span></div><button className="secondary-button" onClick={() => toast.success("Accessible route preference enabled")}>Enable route</button></div></section>;
}

function NotificationsView({ setActive }: { setActive: (view: View) => void }) {
  return <section className="detail-view"><SectionHeading eyebrow="KEEP IN THE LOOP" title="Your alerts" detail="The latest changes around your journey and the bus stand." action={<button className="back-action" onClick={() => setActive("home")}><ArrowRight size={15} className="back-arrow" />Back to overview</button>} /><div className="alert-layout"><div className="alerts-list">{alerts.map((alert) => { const Icon = alert.icon; return <article className="card alert-card" key={alert.title}><div className={`alert-icon alert-${alert.tone}`}><Icon size={18} /></div><div className="alert-copy"><div><strong>{alert.title}</strong><span>{alert.time}</span></div><p>{alert.detail}</p></div><button className="icon-button" onClick={() => toast.info("Alert marked as read")} aria-label={`Dismiss ${alert.title}`}><X size={16} /></button></article>; })}</div><div className="card emergency-card"><div className="emergency-top"><div className="emergency-icon"><ShieldAlert size={21} /></div><StatusPill tone="green">Ready to help</StatusPill></div><p className="eyebrow">IN CASE YOU NEED IT</p><h3>Emergency support</h3><p>Reach the bus stand control room instantly. Share your live location with one tap.</p><div className="emergency-buttons"><button onClick={() => toast.error("Calling control room…")}><Phone size={16} />Control room</button><button onClick={() => toast.success("Live location sharing is ready")}>Share location <ArrowRight size={16} /></button></div></div></div></section>;
}

function ProfileView({ darkMode, onToggleDark, setActive }: { darkMode: boolean; onToggleDark: () => void; setActive: (view: View) => void }) {
  return <section className="detail-view"><SectionHeading eyebrow="YOUR SMARTBUS" title="Passenger profile" detail="Personalise the way SmartBus AI helps you travel." action={<button className="back-action" onClick={() => setActive("home")}><ArrowRight size={15} className="back-arrow" />Back to overview</button>} /><div className="profile-layout"><div className="card profile-card"><div className="profile-head"><div className="profile-avatar-large">AR</div><div><p className="eyebrow">PASSENGER ACCOUNT</p><h3>Arun Raj</h3><span>arun.raj@example.com</span></div><button className="secondary-button">Edit profile</button></div><div className="profile-stats"><div><strong>12</strong><span>Trips taken</span></div><div><strong>4</strong><span>Saved routes</span></div><div><strong>3</strong><span>Favourite stops</span></div></div></div><div className="card preferences-card"><p className="eyebrow">PREFERENCES</p><h3>Make it yours</h3><div className="preference-row"><div className="preference-icon"><Languages size={17} /></div><div><strong>Language</strong><span>English</span></div><ChevronDown size={17} /></div><div className="preference-row"><div className="preference-icon"><Moon size={17} /></div><div><strong>Dark mode</strong><span>{darkMode ? "On" : "Off"}</span></div><button className={`switch ${darkMode ? "switch-on" : ""}`} onClick={onToggleDark} aria-label="Toggle dark mode"><span /></button></div><div className="preference-row"><div className="preference-icon"><Volume2 size={17} /></div><div><strong>Voice guidance</strong><span>English · Tamil</span></div><button className="switch switch-on" aria-label="Voice guidance enabled"><span /></button></div></div></div></section>;
}

export default function Home() {
  const [active, setActive] = useState<View>("home");
  const [query, setQuery] = useState("");
  const [darkMode, setDarkMode] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileNav, setMobileNav] = useState(false);
  const searchInput = useMemo(() => ({ destination: query || undefined, limit: 5 }), [query]);
  const summaryQuery = trpc.busSchedules.summary.useQuery(undefined, { staleTime: 30_000 });
  const scheduleQuery = trpc.busSchedules.search.useQuery(searchInput, { enabled: active === "search", staleTime: 15_000 });

  useEffect(() => {
    document.title = active === "home" ? "SmartBus AI · Your smart travel assistant" : `${navItems.find((item) => item.id === active)?.label ?? "SmartBus"} · SmartBus AI`;
  }, [active]);

  const page = useMemo(() => {
    const props = { setActive, query, setQuery, onSearch: () => { setActive("search"); if (!query) setQuery("Salem"); toast.success("Searching live schedules", { description: "Reading the SmartBus database for matching departures." }); } };
    if (active === "search") return <SearchView {...props} schedules={scheduleQuery.data ?? []} isLoading={scheduleQuery.isLoading} />;
    if (active === "map") return <MapView setActive={setActive} />;
    if (active === "facilities") return <FacilitiesView setActive={setActive} />;
    if (active === "notifications") return <NotificationsView setActive={setActive} />;
    if (active === "profile") return <ProfileView darkMode={darkMode} onToggleDark={() => setDarkMode((value) => !value)} setActive={setActive} />;
    return <HomeView {...props} summary={summaryQuery.data} isSummaryLoading={summaryQuery.isLoading} />;
  }, [active, darkMode, query, scheduleQuery.data, scheduleQuery.isLoading, summaryQuery.data, summaryQuery.isLoading]);

  return <div className={`app-shell ${darkMode ? "app-dark" : ""}`}>
    <AppSidebar active={active} setActive={(view) => { setActive(view); setMobileNav(false); }} collapsed={sidebarCollapsed} onToggle={() => setSidebarCollapsed((value) => !value)} />
    {mobileNav && <button className="mobile-nav-scrim" onClick={() => setMobileNav(false)} aria-label="Close navigation" />}
    <div className={`app-main ${sidebarCollapsed ? "main-expanded" : ""}`}>
      <TopBar darkMode={darkMode} onToggleDark={() => setDarkMode((value) => !value)} onNotifications={() => setActive("notifications")} onMenu={() => setMobileNav(true)} />
      <main className="content-area">{page}</main>
      <footer className="app-footer"><span><BusMark compact /> SmartBus AI</span><span>Built for confident journeys · Coimbatore Central Bus Stand</span><span className="footer-links"><button onClick={() => toast.info("SmartBus AI support is available 24/7")}>Help</button><button onClick={() => toast.info("Privacy controls coming soon")}>Privacy</button></span></footer>
    </div>
  </div>;
}
