# SmartBus AI

SmartBus AI is a React + tRPC + Drizzle/MySQL passenger dashboard for Coimbatore Central Bus Stand. The current feature set exposes recurring bus departures, ranks the next trips in the `Asia/Kolkata` timezone, and lets passengers search by destination, bus number, or route number.

## Quick start

```bash
pnpm install
pnpm dev
```

Useful validation commands:

```bash
pnpm check       # strict TypeScript, no emitted files
pnpm test        # Vitest unit and integration tests
pnpm build       # Vite client build + bundled Node server
```

The application requires the platform-provided environment variables, especially `DATABASE_URL` for the MySQL/TiDB database and the Manus OAuth variables used by the authentication layer. Do not commit `.env` files or copy secret values into source code.

## Architecture

```text
client/src/pages/Home.tsx
        │  typed React hooks
        ▼
client/src/lib/trpc.ts ── HTTP batch link ──> /api/trpc
                                              │
                                              ▼
server/routers.ts ──> server/db.ts ──> Drizzle/MySQL
        │
        └── server/_core/context.ts supplies request, response, and Manus user
```

- `client/src/App.tsx` owns the application shell and wraps the UI in `ErrorBoundary`, `ThemeProvider`, and `TooltipProvider`.
- `client/src/pages/Home.tsx` owns the passenger dashboard and calls the typed `busSchedules.summary` and `busSchedules.search` procedures.
- `server/routers.ts` is the tRPC contract. Keep input validation here and keep SQL/query details in `server/db.ts`.
- `drizzle/schema.ts` is the source of truth for database tables and generated TypeScript row types.
- `drizzle/` contains generated SQL migrations. Review migration SQL before applying it.
- `server/_core/` is framework plumbing. Extend it only when a feature genuinely needs infrastructure changes.

## API reference

All application procedures are served under `/api/trpc`. The frontend should use the generated `trpc` client rather than handwritten `fetch` or Axios calls.

### `busSchedules.summary`

**Procedure:** `publicProcedure.query`

Returns the dashboard aggregate:

```ts
{
  total: number;
  onTime: number;
  nextDeparture: BusScheduleSearch | null;
}
```

`total` is the number of schedule rows, `onTime` counts rows whose status is `on_time` and whose delay is zero, and `nextDeparture` is the nearest recurring departure relative to the current time in `Asia/Kolkata`.

Frontend usage:

```tsx
const summaryQuery = trpc.busSchedules.summary.useQuery(undefined, {
  staleTime: 30_000,
});
```

### `busSchedules.search`

**Procedure:** `publicProcedure.query`

Input is optional. When omitted, the next departures across all destinations are returned.

```ts
{
  destination?: string; // max 128 characters; matched against destination, busNumber, routeNumber
  limit?: number;       // integer from 1 to 10; defaults to 5
}
```

Each result contains the database row plus computed ranking fields:

```ts
{
  id: number;
  busNumber: string;
  routeNumber: string;
  origin: string;
  destination: string;
  platform: number;
  departureMinute: number;
  arrivalMinute: number;
  status: "boarding" | "on_time" | "delayed" | "departed";
  delayMinutes: number;
  walkingMinutes: number;
  serviceDays: string;
  createdAt: Date;
  updatedAt: Date;
  minutesUntilDeparture: number;
  nextDay: boolean;
}
```

Frontend usage:

```tsx
const searchInput = useMemo(
  () => ({ destination: query || undefined, limit: 5 }),
  [query],
);
const scheduleQuery = trpc.busSchedules.search.useQuery(searchInput, {
  enabled: active === "search",
  staleTime: 15_000,
});
```

### `auth.me` and `auth.logout`

- `auth.me` is a public query that returns the current Manus user or `null`.
- `auth.logout` is a public mutation that clears the session cookie. It remains public so an expired or partially initialized session can be cleared safely.

## Database schema

### `users`

| Column | Type | Notes |
| --- | --- | --- |
| `id` | auto-increment integer | Primary key |
| `openId` | `varchar(64)` | Unique Manus OAuth identifier |
| `name` | `text` nullable | Display name |
| `email` | `varchar(320)` nullable | User email |
| `loginMethod` | `varchar(64)` nullable | OAuth/login provider label |
| `role` | `enum('user','admin')` | Defaults to `user` |
| `createdAt` | timestamp | Creation time |
| `updatedAt` | timestamp | Updated automatically |
| `lastSignedIn` | timestamp | Last successful sign-in |

### `busSchedules`

`busSchedules` stores recurring daily departures. It does not store a calendar date; it stores local wall-clock minutes so the same schedule can be reused each day.

| Column | Type | Notes |
| --- | --- | --- |
| `id` | auto-increment integer | Primary key |
| `busNumber` | `varchar(32)` | Passenger-facing bus identifier |
| `routeNumber` | `varchar(32)` | Operator/route code |
| `origin` / `destination` | `varchar(128)` | Route endpoints |
| `platform` | integer | Boarding platform |
| `departureMinute` | integer | Minutes after midnight in `Asia/Kolkata` |
| `arrivalMinute` | integer | Same unit; values above 1440 represent overnight arrival |
| `status` | enum | `boarding`, `on_time`, `delayed`, or `departed` |
| `delayMinutes` | integer | Zero when not delayed |
| `walkingMinutes` | integer | Approximate passenger walk time |
| `serviceDays` | `varchar(32)` | Human-readable recurrence marker; currently `daily` |
| `createdAt` / `updatedAt` | timestamp | Row lifecycle timestamps |

### Time and ranking behavior

`server/db.ts` converts the current instant into an India local minute using `Intl.DateTimeFormat` with `timeZone: "Asia/Kolkata"`. A departure earlier than the current minute is treated as tomorrow by adding 1440 minutes. Results are then sorted by `minutesUntilDeparture`, not by the raw stored minute, so late-night and after-midnight trips are ranked correctly.

The first schedule read performs an idempotent seed of missing default bus numbers. It never overwrites existing rows. When an operator-management workflow is added, that workflow should own edits rather than extending the seed list.

## Migration workflow

When changing `drizzle/schema.ts`:

```bash
pnpm drizzle-kit generate
```

Then inspect the new SQL under `drizzle/`. Confirm that there are no unexpected destructive statements. Apply the reviewed migration through the project database migration workflow; do not use ad-hoc inserts for production seed data.

The generated migration is part of the reviewable source history. Keep the TypeScript schema and the actual database schema synchronized.

## Testing guide

Vitest runs both backend and client component tests through `vitest.config.ts`:

```bash
pnpm test
```

### What the current tests cover

- `server/auth.logout.test.ts` verifies cookie name, security flags, and `maxAge: -1`.
- `server/busSchedules.test.ts` exercises the real tRPC caller against the configured database. It verifies Salem search results, computed `minutesUntilDeparture`, summary totals, on-time counts, and the presence of a next departure.
- `client/src/components/ErrorBoundary.test.tsx` covers the healthy render path, React’s derived error state, and diagnostic logging from `componentDidCatch`.

### Recommended test layers for new features

1. **Pure unit tests:** validate formatting, ranking, normalization, and error-state helpers without I/O.
2. **Router contract tests:** call `appRouter.createCaller(ctx)` and verify input validation, output shape, and authorization behavior.
3. **Database integration tests:** use the configured test database for query ordering, nullability, recurrence, and migration assumptions. Keep assertions stable; avoid asserting the current clock unless the clock is injected or frozen.
4. **Component tests:** cover loading, empty, success, and error states. For components that depend on browser APIs, use a DOM-capable test environment only when necessary and mock external services at the boundary.
5. **Build validation:** run `pnpm check` and `pnpm build` before a checkpoint because type errors and bundler errors can bypass focused tests.

## Error boundaries and error handling

`client/src/components/ErrorBoundary.tsx` wraps the complete application in `App.tsx`. It uses:

- `getDerivedStateFromError` to switch synchronously to a safe fallback UI.
- `componentDidCatch` to log the original error and React component stack for diagnostics.
- A reload action to recover from a poisoned client tree.

An error boundary catches errors thrown during descendant rendering and lifecycle work. It does **not** catch errors from event handlers, asynchronous callbacks, server procedures, or errors thrown by the boundary itself. Those cases must be handled where they occur:

- tRPC queries should expose loading, empty, and error states in the component.
- Mutations should show a user-facing toast and log/telemetry details as appropriate.
- Event handlers should use `try/catch` around imperative work.
- Server procedures should validate inputs with Zod and return typed tRPC errors.
- Never rely on the UI error boundary to hide a backend outage or authorization bug.

When changing the fallback UI, keep the recovery action keyboard accessible and avoid exposing sensitive server data in production error messages. The current implementation displays the client error stack to aid preview debugging; production telemetry should be preferred if a monitoring connector is added.

## Review checklist

Before handing off a change:

- Update `drizzle/schema.ts` and generate/review the migration when schema changes.
- Add or update router contract tests.
- Cover loading, empty, success, and error states in the UI.
- Add comments for timezone, units, ranking, or recovery behavior that is not obvious from the code.
- Run `pnpm check`, `pnpm test`, and `pnpm build`.
- Save a WebDev checkpoint after validation.
