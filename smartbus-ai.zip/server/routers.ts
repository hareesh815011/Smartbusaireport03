import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { getBusScheduleSummary, searchBusSchedules } from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    /** Returns the current Manus user, or null when the visitor is anonymous. */
    me: publicProcedure.query((opts) => opts.ctx.user),
    /** Clears the session cookie; this is public so an expired session can log out safely. */
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  busSchedules: router({
    /**
     * Finds the next recurring departures in Asia/Kolkata time. The optional
     * destination is matched against destination, bus number, and route number.
     */
    search: publicProcedure
      .input(z.object({ destination: z.string().trim().max(128).optional(), limit: z.number().int().min(1).max(10).default(5) }).optional())
      .query(({ input }) => searchBusSchedules(input?.destination, input?.limit ?? 5)),
    /** Returns aggregate schedule counts plus the next departure for the dashboard. */
    summary: publicProcedure.query(() => getBusScheduleSummary()),
  }),
});

export type AppRouter = typeof appRouter;
