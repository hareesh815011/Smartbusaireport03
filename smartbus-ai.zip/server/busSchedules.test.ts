import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("busSchedules", () => {
  it("returns live Salem departures from the database", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const schedules = await caller.busSchedules.search({ destination: "Salem", limit: 5 });

    expect(schedules.length).toBeGreaterThan(0);
    expect(schedules[0]).toMatchObject({ destination: "Salem" });
    expect(typeof schedules[0]?.minutesUntilDeparture).toBe("number");
  });

  it("returns an operational schedule summary", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const summary = await caller.busSchedules.summary();

    expect(summary.total).toBeGreaterThanOrEqual(12);
    expect(summary.onTime).toBeGreaterThan(0);
    expect(summary.nextDeparture).toBeTruthy();
  });
});
