import { and, asc, count, eq, like, or } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  BusSchedule,
  InsertBusSchedule,
  InsertUser,
  busSchedules,
  users,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;
let scheduleSeedPromise: Promise<void> | null = null;

const DEFAULT_SCHEDULES: InsertBusSchedule[] = [
  { busNumber: "TN38 N 2456", routeNumber: "SLE-12", origin: "Coimbatore", destination: "Salem", platform: 12, departureMinute: 705, arrivalMinute: 860, status: "boarding", delayMinutes: 0, walkingMinutes: 2, serviceDays: "daily" },
  { busNumber: "TN38 N 2408", routeNumber: "SLE-08", origin: "Coimbatore", destination: "Salem", platform: 8, departureMinute: 765, arrivalMinute: 915, status: "on_time", delayMinutes: 0, walkingMinutes: 3, serviceDays: "daily" },
  { busNumber: "TN38 N 2512", routeNumber: "SLE-21", origin: "Coimbatore", destination: "Salem", platform: 21, departureMinute: 860, arrivalMinute: 1015, status: "on_time", delayMinutes: 0, walkingMinutes: 4, serviceDays: "daily" },
  { busNumber: "TN38 N 2588", routeNumber: "SLE-26", origin: "Coimbatore", destination: "Salem", platform: 26, departureMinute: 1215, arrivalMinute: 1370, status: "on_time", delayMinutes: 0, walkingMinutes: 4, serviceDays: "daily" },
  { busNumber: "KA01 AB 4112", routeNumber: "BLR-04", origin: "Coimbatore", destination: "Bengaluru", platform: 4, departureMinute: 780, arrivalMinute: 1110, status: "delayed", delayMinutes: 12, walkingMinutes: 3, serviceDays: "daily" },
  { busNumber: "KA01 AB 4220", routeNumber: "BLR-08", origin: "Coimbatore", destination: "Bengaluru", platform: 8, departureMinute: 1275, arrivalMinute: 1605, status: "on_time", delayMinutes: 0, walkingMinutes: 3, serviceDays: "daily" },
  { busNumber: "TN38 N 3304", routeNumber: "MET-04", origin: "Coimbatore", destination: "Mettupalayam", platform: 4, departureMinute: 735, arrivalMinute: 825, status: "on_time", delayMinutes: 0, walkingMinutes: 2, serviceDays: "daily" },
  { busNumber: "TN38 N 3410", routeNumber: "MET-10", origin: "Coimbatore", destination: "Mettupalayam", platform: 10, departureMinute: 900, arrivalMinute: 990, status: "on_time", delayMinutes: 0, walkingMinutes: 3, serviceDays: "daily" },
  { busNumber: "TN38 N 5106", routeNumber: "MDU-06", origin: "Coimbatore", destination: "Madurai", platform: 6, departureMinute: 825, arrivalMinute: 1110, status: "on_time", delayMinutes: 0, walkingMinutes: 3, serviceDays: "daily" },
  { busNumber: "TN38 N 6207", routeNumber: "ERD-07", origin: "Coimbatore", destination: "Erode", platform: 7, departureMinute: 750, arrivalMinute: 840, status: "on_time", delayMinutes: 0, walkingMinutes: 2, serviceDays: "daily" },
  { busNumber: "TN38 N 7109", routeNumber: "TUP-09", origin: "Coimbatore", destination: "Tiruppur", platform: 9, departureMinute: 810, arrivalMinute: 870, status: "on_time", delayMinutes: 0, walkingMinutes: 3, serviceDays: "daily" },
  { busNumber: "TN38 N 8203", routeNumber: "OOT-03", origin: "Coimbatore", destination: "Ooty", platform: 3, departureMinute: 690, arrivalMinute: 930, status: "on_time", delayMinutes: 0, walkingMinutes: 4, serviceDays: "daily" },
  { busNumber: "TN38 N 9011", routeNumber: "CHE-11", origin: "Coimbatore", destination: "Chennai", platform: 11, departureMinute: 1020, arrivalMinute: 1500, status: "on_time", delayMinutes: 0, walkingMinutes: 3, serviceDays: "daily" },
  { busNumber: "TN38 N 4314", routeNumber: "PDE-14", origin: "Coimbatore", destination: "Pollachi", platform: 14, departureMinute: 870, arrivalMinute: 960, status: "on_time", delayMinutes: 0, walkingMinutes: 2, serviceDays: "daily" },
];

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  type TextField = (typeof textFields)[number];

  const assignNullable = (field: TextField) => {
    const value = user[field];
    if (value === undefined) return;
    const normalized = value ?? null;
    values[field] = normalized;
    updateSet[field] = normalized;
  };

  textFields.forEach(assignNullable);
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

async function seedBusSchedules(db: NonNullable<Awaited<ReturnType<typeof getDb>>>) {
  // Seed only missing bus numbers so deploys are safe to repeat and operator-
  // managed rows are not overwritten by application startup.
  const existing = await db.select({ busNumber: busSchedules.busNumber }).from(busSchedules);
  const existingNumbers = new Set(existing.map((row) => row.busNumber));
  const missingSchedules = DEFAULT_SCHEDULES.filter((schedule) => !existingNumbers.has(schedule.busNumber));
  if (missingSchedules.length > 0) await db.insert(busSchedules).values(missingSchedules);
}

async function ensureBusSchedulesSeeded(db: NonNullable<Awaited<ReturnType<typeof getDb>>>) {
  if (!scheduleSeedPromise) {
    scheduleSeedPromise = seedBusSchedules(db).catch((error) => {
      scheduleSeedPromise = null;
      throw error;
    });
  }
  await scheduleSeedPromise;
}

function getIndiaMinuteOfDay(date = new Date()) {
  // The database stores recurring local wall-clock times, so comparison must
  // use the stand’s timezone rather than the server/container timezone.
  const parts = new Intl.DateTimeFormat("en-IN", {
    timeZone: "Asia/Kolkata",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).formatToParts(date);
  const hour = Number(parts.find((part) => part.type === "hour")?.value ?? 0) % 24;
  const minute = Number(parts.find((part) => part.type === "minute")?.value ?? 0);
  return hour * 60 + minute;
}

export type BusScheduleSearch = BusSchedule & {
  minutesUntilDeparture: number;
  nextDay: boolean;
};

export async function searchBusSchedules(destination?: string, limit = 5): Promise<BusScheduleSearch[]> {
  const db = await getDb();
  if (!db) return [];
  await ensureBusSchedulesSeeded(db);

  const normalized = destination?.trim();
  const filters = normalized
    ? or(
        like(busSchedules.destination, `%${normalized}%`),
        like(busSchedules.busNumber, `%${normalized}%`),
        like(busSchedules.routeNumber, `%${normalized}%`),
      )
    : undefined;
  const rows = await db.select().from(busSchedules).where(filters).orderBy(asc(busSchedules.departureMinute));
  const currentMinute = getIndiaMinuteOfDay();

  // Sort after calculating the relative interval so departures just after
  // midnight are correctly ranked ahead of the following day’s later trips.
  return rows
    .map((row) => {
      const isNextDay = row.departureMinute < currentMinute;
      const minutesUntilDeparture = isNextDay
        ? row.departureMinute + 1440 - currentMinute
        : row.departureMinute - currentMinute;
      return { ...row, minutesUntilDeparture, nextDay: isNextDay };
    })
    .sort((a: BusScheduleSearch, b: BusScheduleSearch) => a.minutesUntilDeparture - b.minutesUntilDeparture)
    .slice(0, limit);
}

export async function getBusScheduleSummary() {
  const db = await getDb();
  if (!db) return { total: 0, onTime: 0, nextDeparture: null as BusScheduleSearch | null };
  await ensureBusSchedulesSeeded(db);
  const [totalRows, onTimeRows] = await Promise.all([
    db.select({ total: count() }).from(busSchedules),
    db.select({ total: count() }).from(busSchedules).where(and(eq(busSchedules.status, "on_time"), eq(busSchedules.delayMinutes, 0))),
  ]);
  const nextDeparture = (await searchBusSchedules(undefined, 1))[0] ?? null;
  return {
    total: Number(totalRows[0]?.total ?? 0),
    onTime: Number(onTimeRows[0]?.total ?? 0),
    nextDeparture,
  };
}
