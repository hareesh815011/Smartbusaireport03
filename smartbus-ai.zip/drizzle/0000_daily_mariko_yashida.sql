CREATE TABLE `busSchedules` (
	`id` int AUTO_INCREMENT NOT NULL,
	`busNumber` varchar(32) NOT NULL,
	`routeNumber` varchar(32) NOT NULL,
	`origin` varchar(128) NOT NULL,
	`destination` varchar(128) NOT NULL,
	`platform` int NOT NULL,
	`departureMinute` int NOT NULL,
	`arrivalMinute` int NOT NULL,
	`status` enum('boarding','on_time','delayed','departed') NOT NULL DEFAULT 'on_time',
	`delayMinutes` int NOT NULL DEFAULT 0,
	`walkingMinutes` int NOT NULL DEFAULT 2,
	`serviceDays` varchar(32) NOT NULL DEFAULT 'daily',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `busSchedules_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` int AUTO_INCREMENT NOT NULL,
	`openId` varchar(64) NOT NULL,
	`name` text,
	`email` varchar(320),
	`loginMethod` varchar(64),
	`role` enum('user','admin') NOT NULL DEFAULT 'user',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`lastSignedIn` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `users_id` PRIMARY KEY(`id`),
	CONSTRAINT `users_openId_unique` UNIQUE(`openId`)
);
