import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Recurring daily bus departures at Coimbatore Central Bus Stand.
 * Times are stored as minutes after midnight in Asia/Kolkata so schedules
 * remain date-independent and can be compared safely on the server.
 */
export const busSchedules = mysqlTable("busSchedules", {
  id: int("id").autoincrement().primaryKey(),
  /** Public-facing bus identifier, for example TN38 N 2456. */
  busNumber: varchar("busNumber", { length: 32 }).notNull(),
  /** Operator or route code used by search and passenger displays. */
  routeNumber: varchar("routeNumber", { length: 32 }).notNull(),
  origin: varchar("origin", { length: 128 }).notNull(),
  destination: varchar("destination", { length: 128 }).notNull(),
  platform: int("platform").notNull(),
  /** Minutes after midnight in Asia/Kolkata; recurring schedules are date-independent. */
  departureMinute: int("departureMinute").notNull(),
  /** Minutes after midnight; values greater than 1440 represent overnight arrivals. */
  arrivalMinute: int("arrivalMinute").notNull(),
  /** Operational state shown to passengers. */
  status: mysqlEnum("status", ["boarding", "on_time", "delayed", "departed"]).default("on_time").notNull(),
  /** Positive delay in minutes; keep zero for on-time, boarding, and departed rows. */
  delayMinutes: int("delayMinutes").default(0).notNull(),
  /** Approximate walking time from the passenger’s current stand location. */
  walkingMinutes: int("walkingMinutes").default(2).notNull(),
  /** Human-readable recurrence marker; currently seeded as daily. */
  serviceDays: varchar("serviceDays", { length: 32 }).default("daily").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type BusSchedule = typeof busSchedules.$inferSelect;
export type InsertBusSchedule = typeof busSchedules.$inferInsert;
